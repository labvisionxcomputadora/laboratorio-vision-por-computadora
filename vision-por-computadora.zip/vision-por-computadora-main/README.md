# vision-por-computadora
Página web para el laboratorio de visión por computadora
